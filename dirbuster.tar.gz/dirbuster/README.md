## 工具简介

DirBuster 是一个轻量级后台路径枚举工具，用于探测目标网站可能存在的隐藏目录、敏感文件和管理后台地址。

**本工具使用 Go 语言编写,已编译为各平台可执行文件,需安装 Go 环境即可运行。**

> 本工具仅供授权安全测试使用，请勿用于非法用途。

## 适用场景

- 网站目录结构探测
- 隐藏后台入口发现
- 敏感文件泄露检测
- 授权渗透测试信息收集

## 各系统使用方式

### Android / Termux

```bash
# 将文件放入 Termux 家目录
cp dirbuster ~/
cd ~

# 赋予执行权限
chmod +x dirbuster

# 准备字典文件（每行一个路径）
echo "admin" > dict.txt
echo "login" >> dict.txt
echo "robots.txt" >> dict.txt

# 运行
./dirbuster -u https://目标网站.com -d dict.txt
Windows 系统

```bash
# 在命令提示符或 PowerShell 中
dirbuster.exe -u https://目标网站.com -d dict.txt
```

Linux 系统

```bash
# 赋予执行权限
chmod +x dirbuster_linux

# 运行
./dirbuster_linux -u https://目标网站.com -d dict.txt
```

macOS 系统

```bash
# 赋予执行权限
chmod +x dirbuster_mac

# 运行
./dirbuster_mac -u https://目标网站.com -d dict.txt
```

命令行参数说明

参数 说明
-u 目标网站 URL（必需，需包含协议）
-d 字典文件路径（默认 dict.txt）
-c 并发请求数（默认 20）
-t HTTP 超时时间（默认 5s）
-h 显示帮助信息

使用示例

```bash
# 基本扫描
./dirbuster -u https://example.com -d dict.txt

# 提高并发数加速扫描
./dirbuster -u https://example.com -d dict.txt -c 50

# 设置超时时间
./dirbuster -u https://example.com -d dict.txt -t 3s
```

字典文件格式

字典文件为纯文本格式，每行一个路径，支持 # 开头注释：

```
# 后台路径
admin
login
manage
dashboard

# 敏感文件
robots.txt
.env
config.php
backup.zip
```

输出结果示例

```
[*] 目标: https://example.com/
[*] 字典大小: 10 条

[+] 发现的路径:
  200  https://example.com/robots.txt
  403  https://example.com/admin
  200  https://example.com/sitemap.xml

[*] 共发现 3 个有效路径
```

常见问题

Q: 提示权限不足？
A: 执行 chmod +x 文件名 赋予执行权限。

Q: 扫描速度太慢？
A: 使用 -c 参数提高并发数，如 -c 50。

Q: 提示连接超时？
A: 使用 -t 参数增加超时时间，如 -t 10s。

Q: 没有找到任何路径？
A: 可能是字典不匹配，请更换更大更全的字典文件。

联系方式

· 微信：13546818702
· 邮箱：a765477@qq.com

免责声明

本工具仅供安全测试人员在获得目标系统明确授权的情况下使用。未经授权扫描他人网站属于违法行为，使用者须自行承担一切法律后果。作者不对任何滥用行为负责。

```